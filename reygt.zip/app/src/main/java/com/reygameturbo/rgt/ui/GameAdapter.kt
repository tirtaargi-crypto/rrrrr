package com.reygameturbo.rgt.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.reygameturbo.rgt.R

class GameAdapter(
    private val onLaunch: (AppInfo) -> Unit,
    private val onProfile: (AppInfo) -> Unit
) : RecyclerView.Adapter<GameAdapter.VH>() {
    private val items = mutableListOf<AppInfo>()
    fun submit(data: List<AppInfo>) { items.clear(); items.addAll(data); notifyDataSetChanged() }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_game, parent, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])
    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        private val icon = v.findViewById<ImageView>(R.id.appIcon)
        private val name = v.findViewById<TextView>(R.id.appName)
        private val pkg = v.findViewById<TextView>(R.id.appPackage)
        private val launch = v.findViewById<Button>(R.id.launchButton)
        fun bind(app: AppInfo) {
            icon.setImageDrawable(app.icon); name.text = app.label; pkg.text = app.packageName
            launch.setOnClickListener { onLaunch(app) }
            itemView.setOnClickListener { onProfile(app) }
        }
    }
}
