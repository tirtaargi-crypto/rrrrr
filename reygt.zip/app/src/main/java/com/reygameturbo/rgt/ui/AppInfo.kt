package com.reygameturbo.rgt.ui

data class AppInfo(
    val packageName: String,
    val label: String,
    val icon: android.graphics.drawable.Drawable,
    val launchIntent: android.content.Intent,
    val isGame: Boolean
)
