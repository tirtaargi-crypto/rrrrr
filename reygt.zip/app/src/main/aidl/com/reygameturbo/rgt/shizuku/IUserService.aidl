package com.reygameturbo.rgt.shizuku;

interface IUserService {
    void destroy() = 16777114;
    String execute(String action) = 1;
}
