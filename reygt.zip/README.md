# ReyGameTurbo • RGT

ReyGameTurbo (RGT) is a lightweight Android gaming control center for Android 12+.

## Build target
- Package: `com.reygameturbo.rgt`
- minSdk 31
- targetSdk 35
- compileSdk 35
- Java 17 / Kotlin JVM 17
- AGP 8.7.3
- Gradle 8.9
- Shizuku API 13.1.5

## ZIP → GitHub → APK
1. Put `ReyGameTurbo_RGT_FINAL_1ZIP.zip` in the repository root.
2. Push it to GitHub.
3. Open Actions → **Build ReyGameTurbo RGT from ZIP**.
4. Download artifact **ReyGameTurbo-RGT-debug-apk**.

The workflow rejects zero or multiple root ZIP files, extracts the ZIP, locates `settings.gradle(.kts)` automatically, checks the `app` module and `gradlew`, runs `./gradlew :app:assembleDebug --stacktrace`, verifies an APK exists, and uploads it.

## Shizuku
RGT uses the public Shizuku API and `UserService`; it does not call the private `Shizuku.newProcess()` API. Shizuku is optional. Without it, the app still launches apps, displays monitoring data, and can show the overlay after Android grants overlay permission.

Turbo/Smooth commands are deliberately whitelisted. A command is only sent through the UserService when Shizuku is running and RGT has permission. Failed or unsupported operations are reported instead of being treated as successful.

## Overlay
The crosshair is a visual overlay only. It has no target detection, auto-aim, recoil automation, input automation, memory modification, or anti-cheat bypass.

## Notes
Android does not expose a universal public API for reading the target game's real-time FPS from another app. RGT therefore reports FPS as unavailable rather than inventing a number.
