@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle 8.9 is required. Run from GitHub Actions or install Gradle 8.9+ locally.
exit /b 1
