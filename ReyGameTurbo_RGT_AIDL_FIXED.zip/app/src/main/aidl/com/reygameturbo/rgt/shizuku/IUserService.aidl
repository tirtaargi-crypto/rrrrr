package com.reygameturbo.rgt.shizuku;

interface IUserService {
    void destroy();
    String execute(String action);
}
