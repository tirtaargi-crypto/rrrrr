package com.reygameturbo.rgt.shizuku

import android.content.Context
import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.InputStreamReader

@Keep
class UserService : IUserService.Stub {
    @Keep
    constructor() : super()

    @Keep
    constructor(context: Context) : super()

    override fun destroy() {
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    override fun execute(action: String?): String {
        if (action == null) return "ERROR: missing action"
        val commands = when (action) {
            "turbo_on" -> listOf(
                listOf("settings", "put", "global", "window_animation_scale", "0.5"),
                listOf("settings", "put", "global", "transition_animation_scale", "0.5"),
                listOf("settings", "put", "global", "animator_duration_scale", "0.5")
            )
            "turbo_off" -> listOf(
                listOf("settings", "put", "global", "window_animation_scale", "1.0"),
                listOf("settings", "put", "global", "transition_animation_scale", "1.0"),
                listOf("settings", "put", "global", "animator_duration_scale", "1.0")
            )
            "refresh_60" -> listOf(listOf("settings", "put", "system", "peak_refresh_rate", "60.0"))
            "refresh_90" -> listOf(listOf("settings", "put", "system", "peak_refresh_rate", "90.0"))
            "refresh_120" -> listOf(listOf("settings", "put", "system", "peak_refresh_rate", "120.0"))
            "refresh_144" -> listOf(listOf("settings", "put", "system", "peak_refresh_rate", "144.0"))
            else -> return "ERROR: unsupported action"
        }
        return try {
            commands.joinToString(" | ") { cmd ->
                val process = ProcessBuilder(cmd).redirectErrorStream(true).start()
                val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText().trim() }
                val code = process.waitFor()
                "exit=$code ${if (output.isBlank()) "ok" else output.take(160)}"
            }
        } catch (e: Exception) {
            "ERROR: ${e.javaClass.simpleName}: ${e.message ?: "unknown"}"
        }
    }
}
